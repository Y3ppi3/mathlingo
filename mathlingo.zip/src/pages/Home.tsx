function Home() {
    return (
        <div className="text-center">
            <h1 className="text-3xl font-bold text-blue-600">Главная страница</h1>
            <p>Добро пожаловать в MathLingo!</p>
        </div>
    );
}

export default Home;
