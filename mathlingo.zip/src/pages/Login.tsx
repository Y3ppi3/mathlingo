function Login() {
    return (
        <div className="text-center">
            <h1 className="text-3xl font-bold text-green-600">Вход</h1>
            <p>Введите логин и пароль.</p>
        </div>
    );
}

export default Login;
